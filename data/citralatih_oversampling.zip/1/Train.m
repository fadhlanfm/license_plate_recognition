
a1=imread('1.jpg')
a1=im2bw(a1);
a1dou=im2double(a1);
% a1= imresize(a1, [45 24]);
a1imc=imcomplement(a1);
[L1 num1]=bwlabel(a1);
stats1 = regionprops(a1, 'Image'); % get image features
c = stats1(1);
C = [c.Image];
C= imresize(C, [45 24]);
C=imcomplement(C);
 close all;
 imshow(a1,[]);
 B = reshape(a1,1,[]); %convert to single row array
 A = [A(1:k,:); b; A(k+1:end,:)] %insert new row
 B_isi = [20 B]; %insert class
 
